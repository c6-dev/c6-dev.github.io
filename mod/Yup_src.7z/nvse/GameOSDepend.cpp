#include "GameOSDepend.h"

OSInputGlobals** g_OSInputGlobals = (OSInputGlobals**)0x011F35CC;

OSGlobals ** g_osGlobals = (OSGlobals **)0x011DEA0C;	//in oldWinMain, result of FormHeap_allocate ~Ax.
