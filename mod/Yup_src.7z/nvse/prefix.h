#pragma once

#include "common/IPrefix.h"
#include "nvse/nvse_version.h"
#include "nvse/utility.h"
#include "nvse/containers.h"
