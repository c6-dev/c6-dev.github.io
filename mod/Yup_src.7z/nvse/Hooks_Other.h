#pragma once
#include "GameAPI.h"

namespace OtherHooks
{
	void CleanUpNVSEVars(ScriptEventList* eventList);
	
	void Hooks_Other_Init();
}
