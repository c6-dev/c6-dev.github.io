#pragma once

#if RUNTIME

void Hook_Logging_Init(void);

#endif
