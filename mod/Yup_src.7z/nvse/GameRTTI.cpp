#include "GameRTTI.h"

#if RUNTIME
#include "GameRTTI_1_4_0_525.inc"
#elif EDITOR
#include "GameRTTI_EDITOR.inc"
#endif
