#pragma once

void Hooks_Memory_PreloadCommit(bool isNoGore);
