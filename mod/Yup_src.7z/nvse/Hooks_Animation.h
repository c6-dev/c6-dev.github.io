#pragma once

#if RUNTIME

void Hook_Animation_Init(void);

#endif
