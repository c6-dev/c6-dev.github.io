#pragma once

#if RUNTIME

void Hook_SaveLoad_Init();
extern bool g_gameLoaded;
extern bool g_gameStarted;

#endif
