#include "GameProcess.h"

ActorProcessManager * g_actorProcessManager = (ActorProcessManager*)0x011E0E80;
