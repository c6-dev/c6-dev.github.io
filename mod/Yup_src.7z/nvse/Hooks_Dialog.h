#pragma once

#if RUNTIME

void Hook_Dialog_Init(void);

#endif
